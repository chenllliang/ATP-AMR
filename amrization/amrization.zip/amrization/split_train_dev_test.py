seed = 123
import random
random.seed(seed)

if __name__ == "__main__":
    import sys
    src = open(sys.argv[1],"r").readlines()
    gold = open(sys.argv[2],"r").readlines()
    assert len(src) == len(gold)
    items = list(zip(src,gold))
    random.shuffle(items)
    
    train_src = open(sys.argv[1]+".train","w")
    dev_src = open(sys.argv[1]+".dev","w")
    train_gold = open(sys.argv[2]+".train","w")
    dev_gold = open(sys.argv[2]+".dev","w")
    
    for i in items[:40000]:
        train_src.write(i[0].replace("/.","."))
        train_gold.write(i[1])
    
    for i in items[40000:41500]:
        dev_src.write(i[0])
        dev_gold.write(i[1])


    
