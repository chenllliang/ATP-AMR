import os
from tqdm import tqdm

out = []
pointer_id = 0 
pointer_dict = {}

total_args = 0
reen = 0

class TreeNode:
    def __init__(self,name,types=None):
        self.name = name
        self.type = types #concept or relation

        self.father = None
        self.relation = None
        self.sons = []

    def addFather(self,father,relation):
        self.father = father
        self.relation = relation
        father.sons.append(self)

# from stanfordcorenlp import StanfordCoreNLP
# nlp = StanfordCoreNLP(r'/home/cl/Tools/stanford-corenlp-4.2.2', lang='en')

# sentence = "Germany GDP has grown by the expected wnd France  by %0.4 ."


# def get_triplet_dp(sentence):
#     snt = nlp.word_tokenize(sentence)
#     dp = nlp.dependency_parse(sentence)
#     dp = sorted(dp,key=lambda x:x[2])
#     root_index = [i[1] for i in dp]
#     rel_name = [i[0].lower() for i in dp]
#     return snt,root_index,rel_name



# def get_sentence_root(sentence):
#     snt = nlp.word_tokenize(sentence)
#     dp = nlp.dependency_parse(sentence)
#     root_index = 0
#     for i in dp:
#         if i[0]=="ROOT":
#             root_index = i[2]-1
#     return snt[root_index]

# print(get_sentence_root("Estimated and actual results involving losses"))

class OntoNotes_Srl_Instance:
    def __init__(self, snt, prop):
        self.sentence = snt
        self.propsition = prop

    def lineration_with_reen_noargd_and_predreen(self):
        pass
    
    
    def lineration_with_reen_noargd_and(self):
        global pointer_id
        pointer_id = 0
        if len(self.propsition) > 1:
            root = TreeNode("and","concept")
            snts = []
            for n,i in enumerate(self.propsition):
                cur_node = TreeNode(i["prop"],"rel")
                for j in i.keys():
                    if j!="prop":
                        arg = i[j]
                        temp_node = TreeNode(arg,"concept").addFather(cur_node,j)
                cur_node.addFather(root,":op"+str(n))
        else:
            root = TreeNode(self.propsition[0]['prop'],"rel")
            for j in self.propsition[0].keys():
                if j!="prop":
                    arg = self.propsition[0][j]
                    temp_node = TreeNode(arg,"concept").addFather(root,j)
        
        def traverse_restore_reen(root: TreeNode,depth):
            global out,pointer_id,pointer_dict,total_args,reen
            if(depth!=0):
                out.append(root.relation)
            if len(root.sons)!=0:
                out.append("(")
            
            if root.type == "rel":
                out.append("<pointer:%d> "%(pointer_id)+root.name)
                pointer_id+=1
            else:
                total_args+=1
                if root.name in pointer_dict.keys():
                    reen+=1
                    out.append("<pointer:%d>"%(pointer_dict[root.name]))
                else:
                    out.append("<pointer:%d> "%(pointer_id)+root.name)
                    pointer_dict[root.name] = pointer_id
                    pointer_id+=1
            for i in root.sons:
                traverse_restore_reen(i,depth+1)

            if len(root.sons)!=0:
                out.append(")")

        traverse_restore_reen(root,0)


    def lineration_with_reen_noargd(self):
        global pointer_id
        pointer_id = 0
        if len(self.propsition) > 1:
            root = TreeNode("multi-sentence","rel")
            snts = []
            for n,i in enumerate(self.propsition):
                cur_node = TreeNode(i["prop"],"rel")
                for j in i.keys():
                    if j!="prop":
                        arg = i[j]
                        temp_node = TreeNode(arg,"concept").addFather(cur_node,j)
                cur_node.addFather(root,":snt"+str(n))
        else:
            root = TreeNode(self.propsition[0]['prop'],"rel")
            for j in self.propsition[0].keys():
                if j!="prop":
                    arg = self.propsition[0][j]
                    temp_node = TreeNode(arg,"concept").addFather(root,j)
        
        def traverse_restore_reen(root: TreeNode,depth):
            global out,pointer_id,pointer_dict,total_args,reen
            if(depth!=0):
                out.append(root.relation)
            if len(root.sons)!=0:
                out.append("(")
            
            if root.type == "rel":
                out.append("<pointer:%d> "%(pointer_id)+root.name)
                pointer_id+=1
            else:
                total_args+=1
                if root.name in pointer_dict.keys():
                    reen+=1
                    out.append("<pointer:%d>"%(pointer_dict[root.name]))
                else:
                    out.append("<pointer:%d> "%(pointer_id)+root.name)
                    pointer_dict[root.name] = pointer_id
                    pointer_id+=1
            for i in root.sons:
                traverse_restore_reen(i,depth+1)

            if len(root.sons)!=0:
                out.append(")")

        traverse_restore_reen(root,0)

    # def lineration_with_reentrancy(self):
    #     global pointer_id
    #     pointer_id = 0
    #     if len(self.propsition) > 1:
    #         root = TreeNode("multi-sentence","rel")
    #         snts = []
    #         for n,i in enumerate(self.propsition):
    #             cur_node = TreeNode(i["prop"],"rel")
    #             for j in i.keys():
    #                 if j!="prop":
    #                     arg = i[j]
    #                     if len(arg.split(" ")) > 1:
    #                         arg = get_sentence_root(arg)
    #                     temp_node = TreeNode(arg,"concept").addFather(cur_node,j)
    #             cur_node.addFather(root,":snt"+str(n))
    #     else:
    #         root = TreeNode(self.propsition[0]['prop'],"rel")
    #         for j in self.propsition[0].keys():
    #             if j!="prop":
    #                 arg = self.propsition[0][j]
    #                 if len(arg.split(" ")) > 1:
    #                     arg = get_sentence_root(arg)
    #                 temp_node = TreeNode(arg,"concept").addFather(root,j)
        
        def traverse_restore_reen(root: TreeNode,depth):
            global out,pointer_id,pointer_dict,total_args,reen
            if(depth!=0):
                out.append(root.relation)
            if len(root.sons)!=0:
                out.append("(")
            
            if root.type == "rel":
                out.append("<pointer:%d> "%(pointer_id)+root.name)
                pointer_id+=1
            else:
                total_args+=1
                if root.name in pointer_dict.keys():
                    reen+=1
                    out.append("<pointer:%d>"%(pointer_dict[root.name]))
                else:
                    out.append("<pointer:%d> "%(pointer_id)+root.name)
                    pointer_dict[root.name] = pointer_id
                    pointer_id+=1
            for i in root.sons:
                traverse_restore_reen(i,depth+1)

            if len(root.sons)!=0:
                out.append(")")

        traverse_restore_reen(root,0)

    
    # def lineraztion_with_arg_reduction(self):
    #     # use :snt relation to process multiple verbs, , no re-entrency restore, therefore will generate a tree
    #     global pointer_id
    #     pointer_id = 0
    #     if len(self.propsition) > 1:
    #         root = TreeNode("multi-sentence")
    #         snts = []
    #         for n,i in enumerate(self.propsition):
    #             cur_node = TreeNode(i["prop"])
    #             for j in i.keys():
    #                 if j!="prop":
    #                     arg = i[j]
    #                     if len(arg.split(" ")) > 1:
    #                         arg = get_sentence_root(arg)
    #                     temp_node = TreeNode(arg).addFather(cur_node,j)
    #             cur_node.addFather(root,":snt"+str(n))
    #     else:
    #         root = TreeNode(self.propsition[0]['prop'])
    #         for j in self.propsition[0].keys():
    #             if j!="prop":
    #                 arg = self.propsition[0][j]
    #                 if len(arg.split(" ")) > 1:
    #                     arg = get_sentence_root(arg)
    #                 temp_node = TreeNode(arg).addFather(root,j)


        
        def traverse(root: TreeNode,depth):
            global out,pointer_id
            if(depth!=0):
                out.append(root.relation)
            if len(root.sons)!=0:
                out.append("(")
            

            out.append("<pointer:%d> "%(pointer_id)+root.name)
            pointer_id+=1

            for i in root.sons:
                traverse(i,depth+1)

            if len(root.sons)!=0:
                out.append(")")

        traverse(root,0)
        # print(out)

    def linerazation_with_reen_argr_prer(self):
        pass

    def trival_linerazation(self):
        # use :snt relation to process multiple verbs, no argument reduction, no re-entrency restore, therefore will generate a tree
        # shallow
        global pointer_id
        pointer_id = 0
        if len(self.propsition) > 1:
            root = TreeNode("multi-sentence")
            snts = []
            for n,i in enumerate(self.propsition):
                cur_node = TreeNode(i["prop"])
                for j in i.keys():
                    if j!="prop":
                        temp_node = TreeNode(i[j]).addFather(cur_node,j)
                cur_node.addFather(root,":snt"+str(n))
        else:
            root = TreeNode(self.propsition[0]['prop'])
            for j in self.propsition[0].keys():
                if j!="prop":
                    temp_node = TreeNode(self.propsition[0][j]).addFather(root,j)


        
        def traverse(root: TreeNode,depth):
            global out,pointer_id
            if(depth!=0):
                out.append(root.relation)
            if len(root.sons)!=0:
                out.append("(")
            out.append("<pointer:%d> "%(pointer_id)+root.name)
            pointer_id+=1

            for i in root.sons:
                traverse(i,depth+1)

            if len(root.sons)!=0:
                out.append(")")

        traverse(root,0)
        # print(out)
        








    def getPropsition(self):
        return self.propsition

    def getSentence(self):
        return self.sentence

    def show(self):
        print(self.getSentence())
        for i in self.getPropsition():
            print(i)
        print("-------------------")

    def generate_training_samples_full_verbs(self):
        out = ""
        raw_sent = [i.replace("/", "") for i in self.sentence.split(" ") if "*" not in i and "%" not in i]
        args = self.getPropsition()

        tuples = []

        tgt_tokens = self.getSentence().split()

        current_id=0


    def tp_dfs_full(self,x:list):
        amrs = []
        for i in x:
            ret ="( %s "%i['prop']

            for j, v in i.items():
                if j!="prop" and v!="":
                    ret +="%s ( %s ) "%(j,v)
            ret += " )"

            amrs.append(ret)

        return " ".join(amrs)

    def to_fake_amr(self):
        print(self.sentence)
        print(self.propsition)


    def to_triblets_sentence_full(self,x: list):
        v_id = 0
        tributes = []
        edges = []

        # add instances and edges

        for i in x:
            verb_id = v_id
            tributes.append(["<pointer-%d>" % v_id, ":instance", i['prop'].replace(".","-")])
            v_id += 1

            for j, v in i.items():
                if j!="prop" and j!=":mod" and v!="":
                    tributes.append(["<pointer-%d>" % v_id, ":instance", v])
                    edges.append(["<pointer-%d>" % verb_id, j, "<pointer-%d>" % v_id])

                    v_id += 1

                if j==":mod":
                    tributes.append(["<pointer-%d>" % v_id, ":instance", i.mod])
                    edges.append(["<pointer-%d>" % verb_id, ":mod", "<pointer-%d>" % v_id])
                    v_id += 1

        # add edges
        return str(tributes + edges)

    def generate_training_samples_single_verb(self):
        # only v, args
        out = ""
        raw_sent = [i.replace("/", "") for i in self.sentence.split(" ") if "*" not in i and "%" not in i]
        args = self.getPropsition()

        tuples = []

        tgt_tokens = self.getSentence().split()

        for i in args:
            verb = i['prop']
            for j in i.keys():
                if "mod" in j:
                    tuples.append("%s :mod %s" % (verb, i[j]))
                elif "ARG" in j:
                    tuples.append("%s %s %s" % (verb, j, i[j]))

        return raw_sent, tuples

def clean_text(src):
    temp_tokens = src.split(" ")
    tgts = [i.replace("/", "") for i in temp_tokens if "*" not in i and "%" not in i and "." not in i]
    return " ".join(tgts)


def read_onf_srl(path:str):
    assert path.endswith(".onf")
    instances_str = open(path, "r", encoding="utf-8").read().split("------------------------------------------------------------------------------------------------------------------------")
    args = []
    for j,i in enumerate(instances_str[1:]):
        if "Leaves" in i:
            leaves = i.split("Leaves:\n-------\n")[1]
            #print(j,"\n",leaves)
            lines = leaves.split("\n")
            current_arg = []
            current_temp_arg = {}
            for line in lines:
                if "prop:" in line: #start a new prop-arg pairs

                    if current_temp_arg!={}:
                        current_arg.append(current_temp_arg)
                    current_temp_arg={}

                    prop = line.replace("prop:","").strip()
                    current_temp_arg['prop'] = prop

                elif "ARGM-MNR" in line:
                    mod = line.split(",")[-1].strip()
                    current_temp_arg['mod'] = mod
                elif "ARG0" in line:
                    argx = line.split(",")[-1].strip()
                    current_temp_arg[':ARG0'] = clean_text(argx)
                elif "ARG1" in line:
                    argx = line.split(",")[-1].strip()
                    current_temp_arg[':ARG1'] = clean_text(argx)
                elif "ARG2" in line:
                    argx = line.split(",")[-1].strip()
                    current_temp_arg[':ARG2'] = clean_text(argx)
                elif "ARG3" in line:
                    argx = line.split(",")[-1].strip()
                    current_temp_arg[':ARG3'] = clean_text(argx)
                elif "ARG4" in line:
                    argx = line.split(",")[-1].strip()
                    current_temp_arg[':ARG4'] = clean_text(argx)
                elif "ARG5" in line:
                    argx = line.split(",")[-1].strip()
                    current_temp_arg[':ARG5'] = clean_text(argx)
                elif "ARG6" in line:
                    argx = line.split(",")[-1].strip()
                    current_temp_arg[':ARG6'] = clean_text(argx)
            if current_temp_arg != {}:
                current_arg.append(current_temp_arg)

        args.append(current_arg)

    return args



def read_sentences_from_file_plain(path:str):
    assert path.endswith(".onf")
    t1 = open(path, "r", encoding="utf-8").read().split("Plain sentence:\n---------------\n")
    raw_sentences = []
    for i in t1[1:]:

        sents_block = i.split("Treebanked sentence:")[0].split("\n")
        sentence = ""
        true_block = []

        for i in sents_block:
            if i != "":
                true_block.append(i.strip())

        raw_sentences.append(" ".join(true_block))

    return raw_sentences


def read_sentences_from_file(path: str):
    assert path.endswith(".onf")
    t1 = open(path, "r", encoding="utf-8").read().split("Treebanked sentence:\n--------------------\n")
    raw_sentences = []
    for i in t1[1:]:
        if "Speaker information" in i:
            sents_block = i.split("Speaker information:")[0].split("\n")
        else:
            sents_block = i.split("Tree:")[0].split("\n")
        sentence = ""
        true_block = []

        for i in sents_block:
            if i != "":
                true_block.append(i.strip())

        raw_sentences.append(" ".join(true_block))

    return raw_sentences


def read_props_from_file(path: str):
    # bc/cctv/00/cctv_0000@0000@cctv@bc@en@on 0 10 gold have-v have.01 ----- 10:0-rel
    assert path.endswith(".prop")
    t1 = open(path, "r", encoding="utf-8").readlines()
    props = []
    current_num = 0
    current_prop = []

    for i in t1:

        i = i.strip()
        verb, args = i.split("-----")
        verb = verb.strip()
        args = args.strip()

        verb_i = verb.split(" ")[1:]

        t_prop = {}
        predicate = verb_i[-1]
        t_prop['onf_id'] = int(verb.split(" ")[-5])
        t_prop['verb_sense'] = predicate
        t_prop['args'] = []

        for j in args.split(" "):
            split_index = j.index("-")
            span = j[0:split_index]
            name = j[split_index + 1:]

            if "*" in span:
                continue

            if "," not in span and ";" not in span:
                start, length = span.split(":")
                t_prop['args'].append([name, (int(start), int(start) + int(length))])

            elif "," in span and ";" in span:
                continue

            elif "," in span:
                spans = span.split(",")
                for i in spans:
                    start, length = i.split(":")
                    t_prop['args'].append([name, (int(start), int(start) + int(length))])
            elif ";" in span:
                spans = span.split(";")
                for i in spans:
                    start, length = i.split(":")
                    t_prop['args'].append([name, (int(start), int(start) + int(length))])

        if int(verb_i[0]) == current_num:
            current_prop.append(t_prop)
        else:
            props.append(current_prop)

            current_num = int(verb_i[0])
            current_prop = []
            current_prop.append(t_prop)


    return props


def align_props_sents(sents, props):
    ret = []

    for i in props:
        if len(i) == 0:
            continue
        sent = sents[i[0]['onf_id']]
        ret.append([sent, i])

    return ret


def genearte_instance(sent, prop) -> OntoNotes_Srl_Instance:
    pass


if __name__ == '__main__':
    # args = read_onf_srl("annotations/bc/cctv/00/cctv_0001.onf")
    # sents = read_sentences_from_file("annotations/bc/cctv/00/cctv_0001.onf")
    #
    datasets = []

    #
    # for i in zip(sents,args):
    #     datasets.append(OntoNotes_Srl_Instance(i[0], i[1]))
    #
    # for j in datasets:
    #     print(j.to_triblets_sentence_full(j.getPropsition()))


    # out = open("ontonotes_srl_dfs.txt","w",encoding="utf-8")

    for i in tqdm(os.listdir("annotations")):
        cur_path = "annotations/"+i
        for m in os.listdir(cur_path):
            if m.endswith("txt"):
                continue

            cur_cur_path = cur_path+"/"+m
            for s in os.listdir(cur_cur_path):
                cur_cur_cur_path = cur_cur_path+"/"+s
                j =  os.listdir(cur_cur_cur_path)


                sent_files = sorted([i for i in j if ".onf" in i],key= lambda x:int(x.split(".o")[0][-3:]))

                for i in sent_files:
                    sents = read_sentences_from_file_plain(cur_cur_cur_path+"/"+i)
                    args = read_onf_srl(cur_cur_cur_path+"/"+i)

                    for i in zip(sents,args):
                        datasets.append(OntoNotes_Srl_Instance(i[0], i[1]))

    print(len(datasets))

    num_props = []
    num = 0



    output = open("amrized_srl/reen_restore.txt.gold","w")
    src = open("amrized_srl/reen_restore.txt.gold","w")

    for i in tqdm(datasets):
        out = []
        pointer_id = 0 
        pointer_dict={}
        if len(i.propsition) == 0:
            continue
        try:
            i.lineration_with_reen_noargd_and()
        except:
            continue

        src.write(i.sentence+"\n")
        output.write(" ".join(out)+"\n")
        
    src.close()
    output.close()

    print(total_args,reen)
